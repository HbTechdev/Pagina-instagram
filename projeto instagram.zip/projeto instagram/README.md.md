# Essa é a página do Instagram :clap:

Em meu primeiro projeto de uma página web, fiz algumas alterações no projeto inicial. Estou apenas começando a minha caminhada em programação, mas já tenho certeza que vou me divertir muito durante o trajeto. 

### Conhecimentos utilizados

* [HTML básico](https://www.w3schools.com/html/)
* [CSS básico](https://developer.mozilla.org/pt-BR/docs/Web/CSS)

### Made by a developer in development :boom:





